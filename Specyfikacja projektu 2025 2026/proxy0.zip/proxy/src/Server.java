import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.*;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Server
{

    ServerSocket serverSocket = null;
    DatagramSocket datagramSocket = null;
    Socket clientSocket = null;
    InetAddress clientAddress =  null;

    String protocol;

    int portNumber = 0;

    Server(int port,String protocol)
    {
        portNumber = port;
        this.protocol = protocol;
    }
    void start(HashMap<String,String> nameMap, List<String> serverList)
    {
            try {
                System.out.println("Creating the main " + protocol + " server socket at port " + portNumber);
                if(protocol.equals("TCP"))
                    serverSocket = new ServerSocket(portNumber);
                else if (protocol.equals("UDP"))
                    datagramSocket = new DatagramSocket(portNumber);
                System.out.println(protocol + " Socket created");
            }
            catch (IOException e) {
                System.err.println("Couldn't create a " + protocol + " server socket: " + e);
                System.exit(1);
            }
        while(true) try {
            System.out.println("Waiting for a client");
            Scanner in =  new Scanner("");
            PrintWriter out = new PrintWriter(System.out);

            byte[] buffer = new byte[256];
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

            if(protocol.equals("TCP")) {
                clientSocket = serverSocket.accept();
                clientAddress = clientSocket.getInetAddress();
                System.out.println("A client connected from " + clientSocket.getInetAddress().toString() + ":" + clientSocket.getPort());
                in = new Scanner(clientSocket.getInputStream());
                out = new PrintWriter(clientSocket.getOutputStream(), true);
            }
            else if (protocol.equals("UDP")){
                datagramSocket.receive(packet);
                clientAddress = packet.getAddress();
                int clientPort = packet.getPort();
                System.out.println("A request received from " + clientAddress.toString() + ":" + clientPort);

                in = new Scanner(new ByteArrayInputStream(packet.getData()));
            }

            String command = "";
            String parameter = "";
            String name = "";

            String input = "";
            String output = "";

            command=in.next();
            input = command;

            switch(command) {
                case "GET":
                    parameter=in.next();
                    input += " " + parameter;
                    switch(parameter) {
                        case "NAMES":
                            output = "OK " + nameMap.size() + " " + String.join(" ", nameMap.keySet());
                            if(in.hasNext())
                                Proxy.clientProxySet.add(String.valueOf(clientAddress).substring(1)+":"+in.next()+":"+protocol);
                            break;
                        case "VALUE":
                            name=in.next();
                            input += " " + name;
                            if(nameMap.containsKey(name)) {
                                Client proxyClient = new Client(nameMap.get(name));
                                output = proxyClient.send(input);
                            }
                            else
                                output = "NA";
                            break;
                        default:
                            output = "NA";
                    }
                    break;
                case "SET":
                    name=in.next();
                    String value = in.next();
                    input += " " + name +  " " + value;
                    if(nameMap.containsKey(name)) {
                        Client proxyClient = new Client(nameMap.get(name));
                        output = proxyClient.send(input);
                    }
                    else
                        output = "NA";
                    break;
                case "UPDATE":
                    String clientPort = in.next();
                    Proxy.allServerList.add(String.valueOf(clientAddress).substring(1)+":"+clientPort);
                    Proxy.proxyUpdate();
                    break;
                case "QUIT":
                    for(String addressPortProtocol : serverList)
                    {
                        Client proxyClient = new Client(addressPortProtocol);
                        proxyClient.send(command);
                    }
                    System.out.println("Terminating");
                    System.exit(0);
                default:
                    output = "NA";
            }
            System.out.println("Parsed command: " + input);
            System.out.println("Response: " + output);

            if(protocol.equals("TCP")) {
                out.println(output);
                out.close();
            }
            else if(protocol.equals("UDP")) {
                packet.setData(output.getBytes());
                datagramSocket.send(packet);
            }
            in.close();
        }
        catch (IOException e) {
            System.err.println("Error at work: " + e);
        }
    }
}
