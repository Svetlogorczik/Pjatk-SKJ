import java.util.*;

public class Proxy {
    static int proxyPort = 0;
    static List<String> allServerList = new ArrayList<>();
    static List<String> serverList = new ArrayList<>();
    static HashMap<String,Integer> numMap = new HashMap<>();
    static HashMap<String,String> nameMap = new HashMap<>();
    static Set<String> clientProxySet = Collections.synchronizedSet(new HashSet<String>());

    public static void main(String args[]) {
        for(int i=0; i<args.length;)
        {
            switch (args[i])
            {
                case "-server":
                    allServerList.add(args[i + 1] + ":" + args[i + 2]);
                    i += 3;
                    break;
                case "-port":
                    proxyPort = Integer.parseInt(args[i + 1]);
                    i += 2;
                    break;
                default:
                    System.err.println("Unknown parameter: " + args[i]);
                    i++;
            }
        }
        proxyUpdate();
        System.out.println(nameMap);

        Server proxyServerTCP = new Server(proxyPort,"TCP");
        Server proxyServerUDP = new Server(proxyPort,"UDP");

        new Thread(()->{proxyServerTCP.start(nameMap,serverList);}).start();
        new Thread(()->{proxyServerUDP.start(nameMap,serverList);}).start();

    }

    static void proxyUpdate(){

        new Thread(()->{
            while(!allServerList.isEmpty()) {
                for (String protocol : new String[]{"TCP", "UDP"}) {
                    Iterator<String> it = allServerList.iterator();
                    while (it.hasNext()) {
                        String addressPort = it.next();
                        Client proxyClient = new Client(addressPort + ":" + protocol);
                        String response = proxyClient.send("GET NAMES "+proxyPort);
                        if (response == null)
                            continue;
                        serverList.add(addressPort + ":" + protocol);
                        String[] temp = response.split(" ");
                        int num = Integer.parseInt(temp[1]);
                        for (int i = 2; i < temp.length; i++) {
                            if (!numMap.containsKey(temp[i]) || numMap.get(temp[i]) > num) {
                                numMap.put(temp[i], num);
                                nameMap.put(temp[i], addressPort + ":" + protocol);
                            }
                        }
                        it.remove();
                    }
                }
                try {
                    //System.out.println("Waiting 1 second...");
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            for(String addressPortProtocol : clientProxySet){
                Client proxyClient = new Client(addressPortProtocol);
                proxyClient.send("UPDATE "+proxyPort);
            }
            System.out.println("Sent UPDATE to all client Proxies");
        }).start();
    }
}
